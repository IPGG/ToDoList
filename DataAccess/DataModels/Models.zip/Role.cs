﻿namespace DataAccess.DataModels
{
    public enum Role
    {
        ADMIN,
        USER
    }
}
